/*
* Este es mi primer proyecto en Java
*/
package g2_11; // Los paquetes de Java van siempre en minúscula


public class G2_11 {

    /**
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola mundo"); 
        System.out.println("Vaya follón");
    }

}
