//En este segundo proyecto trabajo con impresiones

package g2_2;


public class G2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.printf("El número %d no tiene decimales. \n", 21);
        System.out.printf("El número %f tiene decimales. \n" , 23.08);
        System.out.printf("El número %.3f sale exactamente con 3 decimales.\n", 21.5);
    }

}
