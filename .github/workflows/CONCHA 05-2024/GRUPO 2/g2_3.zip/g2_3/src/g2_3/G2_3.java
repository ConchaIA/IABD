// En este proyecto vamos a crear un ticket de caja de Zara

package g2_3;


public class G2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println ("Bienvenidos gracias por su compra");
        System.out.println ("Artículo    Precio/Unidad    Nº Unidades");
        System.out.println ("-------------------------------------------");
        System.out.printf ("%-10s       %3.2f            %2d\n", "camisa azul", 19.90,2);
        System.out.printf ("%-10s       %3.2f            %2d\n", "bolso RAMONES", 12.99,1);
        System.out.printf ("%-10s       %3.2f            %2d\n", "calcetines kitty", 8.30,1);
        System.out.printf ("%-10s       %3.2f            %2d\n", "gafas sol", 24.90,1);
    }

}
