/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grupo.pkg1_p2.grupo.pkg1;

/**
 *
 * @author PC10
 */
public class Grupo1_p2Grupo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // actividades (aula)
        
        //Desarrola una aplicacion en la que se declaren dos variables enteras
        // (x e y). Asígnales los valores 200 y 300 respectivamente. Muestra por pantalla
        //El resultado de todas las operaciones aritmeticas.
        
        int x =200;
        int y= 300;
        
                                int suma = x + y ;
                                int resta = x - y ;
                                int mult = x * y ;
                                float div =(float)x / (float)y; // Casting
                                
                                System.out.println("El resultado de la suma es:" + suma);
                                System.out.println("El resultado de la resta es:" + resta);
                                System.out.println("El resultado de la multi es:" + mult);
                                System.out.println("El resultado de la division es:" + div);
                                
                                //Vamos a crear una conversor de pesetas a euros. la cantidad de pesetas 
                                //600 , debemos convertir las pesetas en euros 
                                // y la cantidad de pesetas se almacenara en una variable.
                                //Debemos sacar por pantalla el equivalente en euros.
                                
                               double pesetas = 600.0;

        // Tasa de cambio: 1 euro = 166.386 pesetas
        double tasaCambio = 166.386;

        // Calculamos el equivalente en euros
        double euros = pesetas / tasaCambio;

        // Mostramos el resultado por pantalla
        System.out.println("600 pesetas son aproximadamente " + euros + " euros.");
    }

                                
                               
                               
                     
    
    
}
