/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grupo1.p1;

/**
 *
 * @author Pablo Valle
 */
public class Grupo1P1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Nombre apellido");
                System.out.println("Direccion");
                        System.out.println("Email");
                                System.out.println("Telefono");
                                
                                System.out.println("\n                     ");
                                System.out.println("Hoy comenzamos java");
                                System.out.println("Tenemos clases los:");
                                System.out.println("Martes y jueves");
                                System.out.println();
                                
                                //Variables:
                                //variables de tipos entero
                                int x =140;
                                int y = 200;
                                int z = 0 ;
                                   z = x+y;
                                System.out.println ("x =" + x);
                                System.out.println("Y = " + y);
                                System.out.println("La suma es:" + z );
                                
                                //operaciones
                                int suma;
                                suma = x + y + z;
                                int resta = x - y - z;
                                int mult = x * y * z;
                                float div =(float)x / (float)y; // Casting
                                
                                System.out.println("El resultado de la suma es:" + suma);
                                System.out.println("El resultado de la resta es:" + resta);
                                System.out.println("El resultado de la multi es:" + mult);
                                System.out.println("El resultado de la division es:" + div);
                     
                   //Cadena de caracteres
                   
                   String miPrimeraPalabra = "birra";
                   String miPrimeraFrase = " ¿Donde esta mi birra?";
                   
                   System.out.println("Mi primera Palabra : " + miPrimeraPalabra);
                   System.out.println("Mi primera frase : " + miPrimeraFrase);
                   
                   //tipo de caracter (char)
                   char letra1  = 'b';
                   char letra2  = 'i';
                   char letra3  = 'r';
                   char letra4  = 'r';
                   char letra5  = 'a';
                   
                   System.out.println("Imprime la primera letra: "+ letra1);
                   System.out.println("Todas juntas: "+ letra1+letra2+letra3+letra4+letra5);
                   
                   // tipos primitivos
                   // Valores booleanos (verdadero o falso) 1 bit
                   // char caracteres 8 bits
                   // int numero entero 32 bits
                   // float numeros con decimales 32 bits
                   //double numeros decimales 64 bits
                   
                   // operadores aritméticos
                   // + - /  * %(modulo)
                   // ++ incremento (ejemplo: a++ incrementando el valor de a 1)
                   // -- decremento
                   
                   
                   
    }
    
}
